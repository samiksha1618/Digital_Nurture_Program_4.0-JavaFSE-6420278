INSERT INTO employee (name, permanent, salary) VALUES ('Alice', true, 50000);
INSERT INTO employee (name, permanent, salary) VALUES ('Bob', false, 40000);
INSERT INTO employee (name, permanent, salary) VALUES ('Carol', true, 60000);
