public class FinancialForecast {

    // Recursive method to calculate future value
    public static double forecastFutureValue(double presentValue, double growthRate, int years) {
        // Base case: no more years left
        if (years == 0) {
            return presentValue;
        }
        // Recursive case: apply growth rate and reduce year count
        return forecastFutureValue(presentValue * (1 + growthRate), growthRate, years - 1);
    }

    public static void main(String[] args) {
        double presentValue = 10000; // ₹10,000
        double growthRate = 0.10;    // 10% annual growth
        int years = 5;               // Forecast for 5 years

        double futureValue = forecastFutureValue(presentValue, growthRate, years);
        System.out.printf(" Future Value after %d years: ₹%.2f%n", years, futureValue);
    }
}