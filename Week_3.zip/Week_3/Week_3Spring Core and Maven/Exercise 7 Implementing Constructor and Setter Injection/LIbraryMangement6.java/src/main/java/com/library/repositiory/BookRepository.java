package com.library.repository;

public class BookRepository {
    public void displayBooks() {
        System.out.println("Displaying list of books from BookRepository...");
    }
}
