package com.library.repository;

public class BookRepository {
    public void bookRepoShow() {
        System.out.println("Inside BookRepository");
    }
}
